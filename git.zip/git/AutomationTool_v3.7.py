import pandas as pd
import numpy as np


##################################################################################################################################################################
#Remaining months in 2020 & 2021

m1= ['3/1/2020', '4/1/2020','5/1/2020','6/1/2020', '7/1/2020','8/1/2020','9/1/2020','10/1/2020','11/1/2020','12/1/2020',  
        '1/1/2021','2/1/2021','3/1/2021', '4/1/2021','5/1/2021','6/1/2021', '7/1/2021','8/1/2021','9/1/2021','10/1/2021','11/1/2021','12/1/2021']
x = int(input("How many months remain in the year including the current month?  ") ) + 12
months = m1[-x:]
month_range = x


#Number of remaining months in 2020
projected_port_consumption_rate = (x-12)/12

##################################################################################################################################################################

#input file
model_headers = ['Parameters', 
'Router Upgrade 1A', 'Router Upgrade 1B', 'Router Upgrade 2A', 'Router Upgrade 2B', 'Router Upgrade 3A', 'Router Upgrade 3B',
'P ROUTER 100G LICENSE 1A', 'P ROUTER 100G LICENSE 1B', 'P ROUTER 100G LICENSE 2A', 'P ROUTER 100G LICENSE 2B', 'P ROUTER 100G LICENSE 3A', 'P ROUTER 100G LICENSE 3B', 
'PE 100G LICENSE 1A', 'PE 100G LICENSE 1B', 'PE 100G LICENSE 2A', 'PE 100G LICENSE 2B', 'PE 100G LICENSE 3A', 'PE 100G LICENSE 3B', 
'P ROUTER NEW CARD 1A', 'P ROUTER NEW CARD 1B', 'P ROUTER NEW CARD 2A', 'P ROUTER NEW CARD 2B', 'P ROUTER NEW CARD 3A', 'P ROUTER NEW CARD 3B', 
'PE NEW CARD 1A', 'PE NEW CARD 1B', 'PE NEW CARD 2A', 'PE NEW CARD 2B', 'PE NEW CARD 3A', 'PE NEW CARD 3B', 
'SAT BOX 1A', 'SAT BOX 1B', 'SAT BOX 2A', 'SAT BOX 2B', 'SAT BOX 3A', 'SAT BOX 3B']
model = pd.read_excel('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/Upgrade_Model_Template.xlsx', sheet_name = 'Input',  skiprows = 3)
model.columns = model_headers
model.set_index('Parameters', inplace = True)


#Static
dfx = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/HistoricalPortConsumption.csv')
dffp4 = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/FP4 Sites_v2.csv')
dfsap = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/SAPs.csv')
df_mc_historical = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/Historical_Metro_Core_Aug2018_Dec2019.csv')
df_ac_historical = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/Historical_Access_Apr2018_Dec2019.csv')
df_cf_hubs = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/CF_Hub_Status.csv')

# MetroCore & Access Exports, export all 2020 data
df_metrocore = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/Data_Export__crosstab.csv')
df_ac = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/Export_Data_crosstab.csv')
df_ports = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/Port_Level_crosstab.csv')
df_pairs = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/OU_Pair_Detail_crosstab.csv')
lag_imb = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/AutomationTool/Imbalance_Detail_crosstab.csv')

##################################################################################################################################################################





def _100G_port_counts():
    fp4 = ['7750 SR-14s','7950-XRS20','7750 SR-7s']    
    df_ports.loc[(df_ports['Role'] == 'P ROUTER') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] = 48  -   df_ports['Used Ports'] - df_ports['Granite Pending Port Count']
    df_ports.loc[(df_ports['Role'] == 'S-PE') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] = 24  -   df_ports['Used Ports'] - df_ports['Granite Pending Port Count']
    df_ports.loc[(df_ports['TLA'] == 'RSM') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'P ROUTER') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] - 24
    df_ports.loc[(df_ports['TLA'] == 'FAY') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'P ROUTER') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] - 24
    df_ports.loc[(df_ports['TLA'] == 'NWA') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'P ROUTER') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] - 24
    df_ports.loc[(df_ports['TLA'] == 'NWT') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'P ROUTER') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] - 24
    df_ports.loc[(df_ports['TLA'] == 'WIC') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'P ROUTER') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] - 24
    df_ports.loc[(df_ports['TLA'] == 'CHD') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'P ROUTER') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] - 24
    df_ports.loc[(df_ports['TLA'] == 'MCD') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'P ROUTER') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] - 24
    df_ports.loc[(df_ports['TLA'] == 'ALG') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'S-PE') & (df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] + 24
    df_ports.loc[(df_ports['TLA'] == 'KNN') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'S-PE') &(df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] + 24
    df_ports.loc[(df_ports['TLA'] == 'LPL') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'S-PE') &(df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] + 24
    df_ports.loc[(df_ports['TLA'] == 'CLR') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'S-PE') &(df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] + 24
    df_ports.loc[(df_ports['TLA'] == 'LUL') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'S-PE') &(df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] + 24
    df_ports.loc[(df_ports['TLA'] == 'ELM') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'S-PE') &(df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] + 24
    df_ports.loc[(df_ports['TLA'] == 'BTR') & (df_ports['Port Type'] == '100 Gigabit Ethernet') & (df_ports['Role'] == 'S-PE') &(df_ports['Node Type'].isin(fp4)) ,'Final Port Count'] =  df_ports['Final Port Count'] + 24

    return(df_ports)
    
df_ports =   _100G_port_counts()  


    
def clean_merge_metro_core():    
    df_mc_historical['Key1'] = df_mc_historical['Router IP']+df_mc_historical['Lag']
    df_metrocore['Key1'] = df_metrocore['Router IP']+df_metrocore['Lag']
    df_mc = df_mc_historical.append(df_metrocore)
    df_mc['Lag'] = df_mc['Lag'].astype(str)
    df_mc2 = df_mc[df_mc['Lag'].str.contains("lag")]
    df_mc2['Key'] = df_mc2['Pair Code']
    df_mc2['Key1'] = df_mc2['Router IP']+df_mc2['Lag']
    df_mc2 = df_mc2.drop_duplicates(subset = ['Month of Month','Pair Code','Router IP','Lag','Far End IP'])        
    return(df_mc2)
    
df_mc = clean_merge_metro_core()  





def clean_merge_access():
    df_ac_historical['Key'] = df_ac_historical['Month'] + df_ac_historical['Ring']
    df_ac['Key'] = df_ac['Month'] + df_ac['Ring']
    df1 = df_ac_historical.append(df_ac)
    df2 = df1.drop_duplicates(subset = ['Key'])    
    return (df2)

df_ac_historical = clean_merge_access()




def ports():
    #Merge current Port Inventory with Historical Port Consumption static sheet
    df_ports['Key'] = df_ports['IP'] + df_ports['Port Type'] 
    df = df_ports[['Key','Region', 'Market ', 'Facility', 'TLA', 'Node Type', 'Node Name', 'IP', 'Role', 'Port Type','Available Ports', 'Granite Pending Port Count', 'Final Port Count','Slots Available', 'Total Port Count', 'Used Ports','MDA Free Subslot Count','MDA Free Subslot']]
    dfx['Key'] = dfx['IP'] + dfx['Port Type'] 
    dfx2 = dfx[[ 'Key','2018 Port Consumption', '2019 Port Consumption','Threshold', 'Hub Class', 'Dec 2019 Used Ports']]
    df1 = df.merge(dfx2, on = 'Key', how = 'left')
    df1['2018 Port Consumption'].replace(np.nan, 0, inplace = True)
    df1['2019 Port Consumption'].replace(np.nan, 0, inplace = True)
   
    
    #Calculate YTD port consumption
    ytd_ports_cons = df1['Used Ports'] - df1['Dec 2019 Used Ports']
    df1.drop('Dec 2019 Used Ports', axis = 1, inplace = True)
    df1.insert(df1.columns.get_loc('2019 Port Consumption')+1, '2020 YTD Port Consumption', ytd_ports_cons)
    
    
    #Get projected ports available for ports not equal to 100G since 100G ports only have 1 year of historical data
    df10 = df1.loc[lambda x:x['Port Type']!='100 Gigabit Ethernet']
    avg_cons = ((df10['2018 Port Consumption'] + df10['2019 Port Consumption']) /2) 
    df10.insert(df10.columns.get_loc('2019 Port Consumption')+1,"Average Yearly Port Consumption", avg_cons )
    
    
    #Add historical port consumption from capped hub to new hub for 10G
    hubs = list(zip(df_cf_hubs['IP'].dropna(), df_cf_hubs['Secondary IP'].dropna()))
    for a,b in hubs:
        old_hub = str(a) + '10-Gig Ethernet SF'
        new_hub = str(b) + '10-Gig Ethernet SF'
        port_types =  df10['Port Type'].loc[(df10['IP'] == a)].unique().tolist()        
        if '10-Gig Ethernet SF'  in port_types:
            df10.loc[(df10['Key'] == new_hub) , 'Average Yearly Port Consumption'] =  float(df10.loc[(df10['Key'] == old_hub) ,'Average Yearly Port Consumption']) + float(df10.loc[(df10['Key'] == new_hub), 'Average Yearly Port Consumption'])

    
    #Calculate Projected Ports Available 
    t1 = df10['Final Port Count'] - (df10['Average Yearly Port Consumption'] * projected_port_consumption_rate)
    t2 = t1 - df10['Average Yearly Port Consumption']
    df10.insert(df10.columns.get_loc('2019 Port Consumption')+2,"End of 2020 Projected Ports Available", t1 )
    df10.insert(df10.columns.get_loc('2019 Port Consumption')+3,"End of 2021 Projected Ports Available", t2 )
    
      
    
    #Get projected ports available for portsequal to 100G since 100G ports only have 1 year of historical data
    df100 = df1.loc[lambda x:x['Port Type']=='100 Gigabit Ethernet']
    avg_cons = df100['2019 Port Consumption']
    x = df100.columns.get_loc('2019 Port Consumption')
    df100.insert(x+1,"Average Yearly Port Consumption", avg_cons )
    
    #Add historical port consumption from capped hub to new hub for 100G
    for a,b in hubs:
        old_hub = str(a) + '100 Gigabit Ethernet'
        new_hub = str(b) + '100 Gigabit Ethernet'
        port_types =  df10['Port Type'].loc[(df10['IP'] == a)].unique().tolist()        
        if '100 Gigabit Ethernet'  in port_types:
            df100.loc[(df100['Key'] == new_hub) , 'Average Yearly Port Consumption'] =  float(df100.loc[(df100['Key'] == old_hub) ,'Average Yearly Port Consumption']) + float(df100.loc[(df10['Key'] == new_hub), 'Average Yearly Port Consumption'])

    
    #Calculate Projected Ports Available 
    t1 = df100['Final Port Count'] - (df100['Average Yearly Port Consumption'] * projected_port_consumption_rate)
    t2 = t1 - df100['Average Yearly Port Consumption']
    df100.insert(df100.columns.get_loc('2019 Port Consumption')+2,"End of 2020 Projected Ports Available", t1 )
    df100.insert(df100.columns.get_loc('2019 Port Consumption')+3,"End of 2021 Projected Ports Available", t2 )
    
    

    #Combine the 10G & 100G Projected Port DF's
    df1 = df10.append(df100)
    df1.drop('Key', axis = 1, inplace = True)    
    
    #Get list of capped hubs & create new field
    capped = df_cf_hubs['TLA'].unique().tolist()
    for i in capped:
        df1.loc[(df1['TLA'] == i) , 'Facility Status'] = 'Capped'   
    
    
    return (df1)

dfx = ports()




def poi(): 
    #Merge port data with static POI data to determine when facilities are receiving FP4 routers
    dfx.loc[dfx['Facility'] == 'New Holt', 'TLA'] = 'NHT'
    dfx.loc[dfx['Facility'] == 'Poydras', 'TLA'] = 'POY'
    
    #P Routers
    dffp4['Key'] = dffp4['TLA'] + dffp4['Role']
    df = dffp4.loc[lambda x:x['Role']!='S-PE']
    dfx['Key'] = dfx['TLA'] + dfx['Role']    
    dfz = df[['Key','FP4 Router Type', 'FP4 Need By Date']].drop_duplicates()
    dfx1 = dfx.loc[lambda x:x['Role']!='S-PE']
    df1 = dfx1.merge(dfz, how = 'left', on = 'Key')      

    #PE Routers   
    dfpe = dffp4.loc[lambda x:x['Role']=='S-PE']
    dfx2 = dfx.loc[lambda x:x['Role']=='S-PE']
    dfpe2 = dfpe[['Node Name','FP4 Router Type', 'FP4 Need By Date']]
    df2 = dfx2.merge(dfpe2, on = 'Node Name', how = 'left')
    
    
    dfb = df1.append(df2) 
    dfb.drop_duplicates(inplace = True)
    
    #Get list of facilities receiving FP4 PE or HYBRID routers
    hybrid = dffp4['TLA'].loc[(dffp4['FP4 Role'] == 'HYBRID')].drop_duplicates().tolist()
    pe = dfpe['TLA'].drop_duplicates().tolist()
    fp4 = hybrid + pe
    dfb['FP4 planned/enabled'] = dfb.apply(lambda x: int(x['TLA'] in fp4), axis=1)  
    dfb['FP4 planned/enabled'] = dfb['FP4 planned/enabled'].replace({1: 'Yes', 0:'No', np.nan:'No'})    
    df2 = dfb.merge(dfsap, how = 'outer', on = 'Node Name')
    df2.drop('Key', axis = 1, inplace = True)
    return(df2)
    
dfx = poi()

    







def secondary_pair():
    #Function to determine which facilities have secondary pairs
    df1 = df_ports[['TLA','Node Name','Port Type', 'Role']]
    df2 = df1.loc[lambda x:x['Port Type']=='10-Gig Ethernet SF']
    df2 = df2.loc[lambda x:x['Role']=='S-PE'] 
    df2.dropna(subset = ['TLA'],axis = 0, inplace = True)
    df2.set_index('TLA', inplace = True)
    pairs = df2.index.value_counts() >= 3
    df3 = df2[pairs]
    df3.reset_index(inplace = True)
    nodes = df3['Node Name'].tolist()
    nodes.append('ELCNIESA02')
    nodes.append('ELCNIESA01')
    nodes.append('FED1IESA02')
    nodes.append('FED1IESA01')   
    dfx['Secondary Pair'] = dfx.apply(lambda x: int(x['Node Name'] in nodes), axis=1)  
    dfx['Secondary Pair'] = dfx['Secondary Pair'].replace({1: 'Yes', 0:'No', np.nan:'No'})
    return(dfx)
    
dfx = secondary_pair() 




    
    
def lag_ut_forecast():
    
    
    #Filter out invalid pairs
    dfa = df_mc.loc[lambda x:x['Key'] != 'None']    
    df = dfa[['Key','Month of Month','Lag Capacity (Gbps)','Pair Utilization ']].drop_duplicates()
    df['Month'] = pd.to_datetime(df['Month of Month'])    
    
    #get valid pair codes & add temp pair codes
    keys = df_pairs['Pair Code'].unique().tolist()   
        
    df_final = pd.DataFrame()    
    for j in keys:
        df1 = df.loc[lambda x: x['Key'] == j]
        df1['Pair Utilization '] = df1['Pair Utilization '].str.replace('%','')
        df1['Pair Utilization '] = pd.to_numeric(df1['Pair Utilization '],errors='coerce')
        df2 = df1.drop_duplicates()
        x = df2['Pair Utilization '].pct_change()
        x = x.replace([np.inf, -np.inf], np.nan)
        y = x.mean() 
        if y < 0:
            y = 0 
        elif y > 0.06:
            y = 0.015
        
        if len(df1) >= 4:
            e = df1['Pair Utilization '][-4:].mean()
        else:
            e = df1['Pair Utilization '].mean()       
    
        r = y + 1    
        forecast_util = []        
        for i in range(0,month_range):
            z = e*r
            forecast_util.append(z)
            e = z            
    
        test = pd.DataFrame()    
        test['Month of Month'] = months
        test['Pair Utilization '] = forecast_util
        test['Key'] = j
        #x = (df1['Lag Capacity (Gbps)'].tail(2).unique().tolist())
        #res =  [ele for ele in x for i in range(int(len(test)/2))] 
        #res1 = res[0:month_range]
        test['Lag Capacity (Gbps)'] = int(df1['Lag Capacity (Gbps)'].tail(1))
    
        jn = pd.concat([df1,test])  
        df_final = df_final.append(jn)
        
    df_final['Pair Capacity Check'] =     df_final['Key'] + df_final['Month of Month']
    cap = df_final['Pair Capacity Check'].value_counts()
    #cap = cap.reset_index()
    df_final2 = df_final.merge(cap, left_on = 'Pair Capacity Check', right_index = True)
    
    df_final3 = df_final2[[ 'Key', 'Month of Month', 'Lag Capacity (Gbps)','Pair Utilization ','Pair Capacity Check_y']]
    df_final3.rename(columns = {'Pair Capacity Check_y':'Lag Pair Capacity Difference'}, inplace = True)
    df_final3['Lag Pair Capacity Difference'] = df_final3['Lag Pair Capacity Difference'].astype(str)
    df_final3['Lag Pair Capacity Difference'].replace('1','No', inplace = True)
    df_final3['Lag Pair Capacity Difference'].replace('2','Yes', inplace = True)
    
    df_final3['Month of Month'] = pd.to_datetime(df_final3['Month of Month'] )
    
    return(df_final3)
    
lag_util_forecast = lag_ut_forecast()







def ring_agg():
    
    df_ac_historical['Month'] = pd.to_datetime(df_ac_historical['Month'])
    df_current_rings = df_ac_historical.loc[lambda x:x['Month'] == df_ac_historical['Month'].unique().max()] 
    df_current_rings.dropna(subset = ['Ring'],axis = 0, inplace = True)
    df_node_count = df_current_rings[['P1 Node Name',' Capacity (Gbps)']]
    dfn = pd.DataFrame()
    for i in df_node_count['P1 Node Name'].unique():
        df = df_node_count.loc[lambda x:x['P1 Node Name']== i]
        x = df[' Capacity (Gbps)'].value_counts()
        x2 = x.reset_index()
        x2['P1 Node Name']= i
        dfn = dfn.append(x2)
        
    dfn2 = dfn.pivot(index ='P1 Node Name', columns = 'index', values = ' Capacity (Gbps)')
    dfn2.reset_index(inplace = True)
    dfn2.drop([100.0,50.0,30.0,20.0], axis = 1, inplace = True)
    dfn2.rename(columns = {1.0:'Number of 1G Rings', 10.0: 'Number of 10G Rings'}, inplace = True)
    dfn3 = dfn2.rename(columns = {1.0:'Number of 1G Rings', 10.0: 'Number of 10G Rings', 'P1 Node Name':'Node Name'})    
    df1 = dfx.merge(dfn3, how = 'left', on = 'Node Name')
    return (dfn2, df_current_rings, df1)

ring_agg, df_current_rings, dfx = ring_agg()







def ring_forecast():
    dfc = df_current_rings[df_current_rings['Ring Utilization'] != '0%']
    dfc.dropna(subset = ['Ring Utilization'], inplace = True)
    currents_rings =  dfc['Ring'].unique()
    df1 =  df_ac_historical[df_ac_historical['Ring'].isin(currents_rings)]    
    #dfz = df1.loc[lambda x:x['Ring'] == '174.77.16.32:4/1/7,174.77.16.2:4/1/7']
    #df2 = df1[df1['Ring Utilization'] != '0%']
    df2 = df1.copy()
    rings = df2['Ring'].dropna().unique()
    test = df2[['Month','Ring', 'Ring Utilization']]
    test['Ring Utilization'] = test['Ring Utilization'].str.replace('%','')
    test['Ring Utilization'] = pd.to_numeric(test['Ring Utilization'],errors='coerce')
    
    df_final = pd.DataFrame()
    
    for i in rings:
    
        df1 = test.loc[lambda x:x['Ring'] == i]   
        df2 = df1.drop_duplicates()
        x = df2['Ring Utilization'].pct_change()
        x = x.replace([np.inf, -np.inf], np.nan)
        if len(df1) == 1:
            x = x.replace(np.nan, int(df2['Ring Utilization'].tail(1)))
        y = x.mean() 
        if y < 0:
            y = 0 
        elif y > 0.06:
            y = 0.015
        
        if len(df1) >= 2:
            e = df1['Ring Utilization'][-2:].mean()
        else:
            e = df1['Ring Utilization'].mean()    
        
        
        r = y + 1    
        forecast_util = []
        
        for j in range(0,month_range):
            z = e*r
            forecast_util.append(z)
            e = z
        
        
        
        test2 = pd.DataFrame()    
        test2['Month'] = pd.to_datetime(months)
        test2['Ring Utilization'] = forecast_util
        test2['Ring'] = i
    
        
        jn = pd.concat([df1,test2])  
        df_final = df_final.append(jn)
        
    return(df_final)
        
ring_util_forecast = ring_forecast()
    







def clean_merge_final():
    #metro
    df1 = df_mc[['Region ', 'Market ', 'Facility', 'TLA', 'Pair Code','Router','Router Type', 'Role ', 'Router Type','Lag','Far End Router ', 'Far_End Role']]
    df2 = df1.merge(lag_util_forecast, how = 'right',left_on = 'Pair Code', right_on = 'Key')
    df3 = df2.drop_duplicates(subset = ['Router', 'Key', 'Month of Month','Lag Capacity (Gbps)'])
    df3.drop('Key' , axis = 1, inplace = True)
    df4 = df3[['Month of Month','Region ', 'Market ', 'Facility', 'TLA', 'Pair Code','Router','Router Type', 'Role ', 'Router Type','Lag','Far End Router ', 'Far_End Role', 'Lag Capacity (Gbps)',
           'Pair Utilization ', 'Lag Pair Capacity Difference']]
    df4.sort_values(by = ['Pair Code', 'Month of Month'],inplace = True)
    
    
    #access
    df5 = df_ac[['Region ', 'Market  ','P1 Facility',  'P2 Facility', 'P1 Node Name', 'P2 Node Name','Ring','carrier', 'bronze', 'silver', 'gold', 'platinum']]
    df6 = df5.merge(ring_agg, how = 'right', on = 'P1 Node Name')
    df7 = df6.merge(ring_util_forecast, how = 'right', on = 'Ring')
    df8 = df7[['Month','Region ', 'Market  ', 'P1 Facility', 'P2 Facility', 'P1 Node Name',
           'P2 Node Name','Number of 1G Rings', 'Number of 10G Rings', 'Ring', 
            'Ring Utilization','carrier', 'bronze', 'silver', 'gold', 'platinum']]
    df9 = df8.drop_duplicates()
    df9.sort_values(by = ['P1 Node Name', 'Month'],inplace = True)
    return (df4,df9)

metro_final, access_final = clean_merge_final()








def lag_upgrades():
    df = metro_final[metro_final['Month of Month'] >= df_current_rings.Month.unique().max()] 
    dfa = df[df['Pair Utilization '] >= 70]
    df_lags = pd.DataFrame()
    keys = dfa['Router'].unique().tolist()
    for i in keys:
        df1 = dfa[dfa['Router']== i]
        lag_cap = df1['Lag Capacity (Gbps)'].drop_duplicates()
        node1 = df1['Router']
        node2 = df1['Far End Router '].drop_duplicates()
        fen = pd.DataFrame()
        fen['Lag Capacity (Gbps)'] = lag_cap
        fen['Router'] = node2
        fen['Number of Forecasted Lag Upgrades'] = 1        
        df_lags = df_lags.append(fen)
        df2 = pd.DataFrame()
        df2['Lag Capacity (Gbps)'] = lag_cap
        df2['Router'] = node1
        df2['Number of Forecasted Lag Upgrades'] = df1['Pair Code'].nunique()
        
        df_lags = df_lags.append(df2)
    df_lags.drop_duplicates(inplace = True)    
    df_lags.rename(columns = {'Router':'Node Name'}, inplace = True) 
    
    lag_aug_100G = df_lags['Node Name'][df_lags['Lag Capacity (Gbps)']>=50].tolist()
    lag_aug_10G = df_lags['Node Name'][(df_lags['Lag Capacity (Gbps)']>=10) & (df_lags['Lag Capacity (Gbps)']< 50)].tolist()


    
    df = dfx.copy()
    df['Key'] = df['Node Name'] + df['Port Type']
    for a in lag_aug_100G:
        key = str(a) + '100 Gigabit Ethernet'
        if key in df.Key.unique().tolist():
            df.loc[(df['Key'] == key) , 'Projected 100G Growth'] = 'Yes' 
            #df.loc[(df['Key'] == key) , 'End of 2020 Projected Ports Available'] =  float(df.loc[(df['Key'] == key) ,'End of 2020 Projected Ports Available']) - 1.0
            df.loc[(df['Key'] == key) , 'End of 2021 Projected Ports Available'] =  float(df.loc[(df['Key'] == key) ,'End of 2021 Projected Ports Available']) - 1.0
        
    for b in lag_aug_10G:
        key = str(b) + '10-Gig Ethernet SF'
        if key in df.Key.unique().tolist():
            #df.loc[(df['Key'] == key) , 'End of 2020 Projected Ports Available'] =  float(df.loc[(df['Key'] == key) ,'End of 2020 Projected Ports Available']) - 1.0
            df.loc[(df['Key'] == key) , 'End of 2021 Projected Ports Available'] =  float(df.loc[(df['Key'] == key) ,'End of 2021 Projected Ports Available']) - 1.0

    
    return(df)
    
dfx = lag_upgrades()
     
   


  

def lag_imb_augment():

    df = lag_imb        
    df['Lag Imbalance '] = df[ 'Lag Imbalance '].str.replace('%','')
    df['Lag Imbalance '] = pd.to_numeric(df[ 'Lag Imbalance '],errors='coerce')
    df1 = df.loc[(df['Lag Imbalance ']>=50) & (df['Lag Imbalance ']<=105)]
    df1.rename(columns = {'Router':'Node Name'}, inplace = True)   
    #imb_keys = df1['Node Name'] + df1['Lag']
    #dfm = df_mc.loc[lambda x:x['Month of Month'] == df_mc['Month of Month'].unique().max()] 
    #dfm['Key'] = dfm['Router'] + dfm['Lag']
    #dfz = dfm[dfm['Key'].isin(imb_keys)]    
    lag_aug_100G1 = df1['Node Name'][df1['Port Capacity Gbps']>=50].tolist()
    lag_aug_100G2 = df1['Far End Router '][df1['Port Capacity Gbps']>=50].tolist()
    lag_aug_100G = set(lag_aug_100G1 + lag_aug_100G2)
    lag_aug_10G1 = df1['Node Name'][(df1['Port Capacity Gbps']>=1) & (df1['Port Capacity Gbps']< 50)].tolist()
    lag_aug_10G2 = df1['Far End Router '][(df1['Port Capacity Gbps']>=1) & (df1['Port Capacity Gbps']< 50)].tolist()
    lag_aug_10G = set(lag_aug_10G1 + lag_aug_10G2)
    
    df = dfx.copy()
    for a in lag_aug_100G:
        key = str(a) + '100 Gigabit Ethernet'
        if key in df.Key.unique().tolist():
            df.loc[(df['Key'] == key) , 'End of 2020 Projected Ports Available'] =  float(df.loc[(df['Key'] == key) ,'End of 2020 Projected Ports Available']) - 1.0
            df.loc[(df['Key'] == key) , 'End of 2021 Projected Ports Available'] =  float(df.loc[(df['Key'] == key) ,'End of 2021 Projected Ports Available']) - 1.0
            df.loc[(df['Key'] == key) , 'Projected 100G Growth'] = 'Yes' 

    for b in lag_aug_10G:
        key = str(b) + '10-Gig Ethernet SF'
        if key in df.Key.unique().tolist():
            df.loc[(df['Key'] == key) , 'End of 2020 Projected Ports Available'] =  float(df.loc[(df['Key'] == key) ,'End of 2020 Projected Ports Available']) - 1.0
            df.loc[(df['Key'] == key) , 'End of 2021 Projected Ports Available'] =  float(df.loc[(df['Key'] == key) ,'End of 2021 Projected Ports Available']) - 1.0


    df["End of 2021 Projected Ports Available"] = df["End of 2021 Projected Ports Available"].round(1)
    df["End of 2020 Projected Ports Available"] = df["End of 2020 Projected Ports Available"].round(1)
    df.drop('Key', axis = 1, inplace = True)

    return(df)
    
dfx =  lag_imb_augment()








def router_upgrades():
#Minimum Requirements    
    df1 = dfx[dfx['FP4 planned/enabled']=='No']
    core = ['HYBRID','S-PE']
    df2 = df1[df1['Role'].isin(core)]
    df3 = df2.loc[lambda x:x['Port Type']=='10-Gig Ethernet SF']
    df4 = df3[df3['Facility Status']!= 'Capped']
    df_min_req = df4[df4['TLA'].notnull()]
    
#Rank1    
    rank1 = df_min_req[(df_min_req['Slots Available']==0) & (df_min_req['MDA Free Subslot Count']==0)]  
    rank11 = df_min_req[(df_min_req['# of SAPs >= 10G']>= 1) & (df_min_req['Slots Available']<=1)]
    df_both = rank1.append(rank11)
    router_upgrades1 = df_both['Node Name'].unique().tolist()
    for i in router_upgrades1:
        dfx.loc[(dfx['Node Name'] == i) , 'Upgrade Type'] = 'FP4 PE ROUTER' 
        dfx.loc[(dfx['Node Name'] == i) , 'Upgrade Rank'] = 1
    

#Rank2    
    rank2a = df_min_req[(df_min_req['Slots Available']<=1) & (df_min_req['End of 2021 Projected Ports Available']<=10)]  
    rank2b = df_min_req[(df_min_req['Projected 100G Growth']=='Yes')]  
    rank2 = rank2a.append(rank2b)
    router_upgrades2 = rank2['Node Name'].unique().tolist()
    router_upgrades2 = [x for x in router_upgrades2 if x not in router_upgrades1]
    for i in router_upgrades2:
        dfx.loc[(dfx['Node Name'] == i) , 'Upgrade Type'] = 'FP4 PE ROUTER' 
        dfx.loc[(dfx['Node Name'] == i) , 'Upgrade Rank'] = 2   
 

#Rank3
    rank3 = df_min_req[(df_min_req['Slots Available']<=3) & (df_min_req['End of 2021 Projected Ports Available']<=10) & (df_min_req['Hub Class'].isin([1,2,3]))]  
    router_upgrades3 = rank3['Node Name'].unique().tolist()
    router_upgrades3 = [x for x in router_upgrades3 if x not in router_upgrades2]  
    router_upgrades3 = [x for x in router_upgrades3 if x not in router_upgrades1]  
    for i in router_upgrades3:
        dfx.loc[(dfx['Node Name'] == i) , 'Upgrade Type'] = 'FP4 PE ROUTER' 
        dfx.loc[(dfx['Node Name'] == i) , 'Upgrade Rank'] = 3
        
    router_upgrades = set(router_upgrades1 +router_upgrades2 +router_upgrades3 )
    
    return(dfx,router_upgrades)

dfx,router_upgrades = router_upgrades()










def new_uplinks():
    dfa = dfx.copy()   
    fp4nodes = dfa['TLA'] + dfa['Node Type']
    df = dffp4.copy()
    df['FP4 Need By Date'] = pd.to_datetime(df['FP4 Need By Date'])
    pe = df.loc[lambda x:x['Role'] == 'S-PE']
    pe['Key'] = pe['TLA'] + pe['FP4 Router Type']
    pe1 = pe[~pe['Key'].isin(fp4nodes)]
    pe2 = pe1.drop_duplicates(subset = ['TLA'] )
    market1 = pe2['Market'].tolist() 
    market2 = dfa.loc[dfa['Upgrade Type']=='FP4 PE ROUTER'].drop_duplicates(subset = 'TLA')
    poi_markets = market2['Market '].tolist()
    poi_and_upgrades = market1 + poi_markets    
    
    for i in poi_and_upgrades:        
        dfa.loc[(dfa['Market '] == i) & (dfa['Role']=='P ROUTER')  & (dfa['Port Type']=='100 Gigabit Ethernet'), 'End of 2020 Projected Ports Available'] =  (dfa.loc[(dfa['Market '] == i) & (dfa['Role']=='P ROUTER')  & (dfa['Port Type']=='100 Gigabit Ethernet') , 'End of 2020 Projected Ports Available']) - 1
        dfa.loc[(dfa['Market '] == i) & (dfa['Role']=='P ROUTER')  & (dfa['Port Type']=='100 Gigabit Ethernet'), 'End of 2021 Projected Ports Available'] =   (dfa.loc[(dfa['Market '] == i) & (dfa['Role']=='P ROUTER')  & (dfa['Port Type']=='100 Gigabit Ethernet') , 'End of 2021 Projected Ports Available']) - 1
        dfa.loc[(dfa['Market '] == i) & (dfa['Role']=='P ROUTER')  & (dfa['Port Type']=='100 Gigabit Ethernet'), 'Projected 100G Growth'] = 'Yes'    
        dfa.loc[(dfa['Market '] == i) & (dfa['Role']=='P ROUTER')  & (dfa['Port Type']=='100 Gigabit Ethernet'), 'New FP4 PE Uplinks Planned in 2020 or 2021'] = 'Yes'    

    
    return(dfa)    
    
    
dfx = new_uplinks()


    





def license_upgrade():
    df1 = dfx[dfx['Port Type']=='100 Gigabit Ethernet']
    fp4 = ['7750 SR-14s','7950-XRS20','7750 SR-7s']
    df_min_req = df1[df1['Node Type'].isin(fp4)]
    df_p_router = df_min_req[df_min_req['Role'] == 'P ROUTER']
    df_pe_router =  df_min_req[df_min_req['Role'] == 'S-PE']
    
#P routers
    p_rank1 = df_p_router[df_p_router['End of 2021 Projected Ports Available'] <= 6 ]  
    p_router_license_upgrade = p_rank1['Node Name'].unique().tolist()
    p_router_license_upgrade = [x for x in p_router_license_upgrade if x not in router_upgrades]
    for i in p_router_license_upgrade:
        dfx.loc[(dfx['Node Name'] == i) & (dfx['Port Type'] == '100 Gigabit Ethernet'), 'Upgrade Type'] = '100G LICENSE: P ROUTER'       
        dfx.loc[(dfx['Node Name'] == i) & (dfx['Port Type'] == '100 Gigabit Ethernet'),  'Upgrade Rank'] = 1
        
#PE routers        
    pe_rank1 = df_pe_router[df_pe_router['End of 2021 Projected Ports Available'] <= 3 ]  
    pe_router_license_upgrade = pe_rank1['Node Name'].unique().tolist()
    pe_router_license_upgrade = [x for x in pe_router_license_upgrade if x not in p_router_license_upgrade]  
    for i in pe_router_license_upgrade:
        dfx.loc[(dfx['Node Name'] == i) & (dfx['Port Type'] == '100 Gigabit Ethernet'), 'Upgrade Type'] = '100G LICENSE: S-PE ROUTER'       
        dfx.loc[(dfx['Node Name'] == i) & (dfx['Port Type'] == '100 Gigabit Ethernet'),  'Upgrade Rank'] = 1
    
    license_upgrades = set(p_router_license_upgrade + pe_router_license_upgrade)    
        
    return(dfx, license_upgrades)
    
dfx,license_upgrades = license_upgrade()







def sat_box():
    df1 = dfx[dfx['Port Type']=='10-Gig Ethernet SF']
    fp4 = ['7750 SR-14s','7950-XRS20','7750 SR-7s']
    df_min_req = df1[df1['Node Type'].isin(fp4)]    
    
#Rank1
    rank1 = df_min_req[df_min_req['End of 2021 Projected Ports Available'] <= 10 ]  
    sat_box1 = [x for x in rank1['Node Name'] if x not in license_upgrades]
    for i in sat_box1:
        dfx.loc[(dfx['Node Name'] == i) & (dfx['Port Type'] == '10-Gig Ethernet SF'), 'Upgrade Type'] = 'Satellite Box: 10G'       
        dfx.loc[(dfx['Node Name'] == i) & (dfx['Port Type'] == '10-Gig Ethernet SF'),  'Upgrade Rank'] = 1

#Rank 2       
    rank2 = df_min_req[df_min_req['End of 2021 Projected Ports Available'] <= 20 ]  
    sat_box2 = [x for x in rank2['Node Name'] if x not in sat_box1]
    for i in sat_box2:
        dfx.loc[(dfx['Node Name'] == i) & (dfx['Port Type'] == '10-Gig Ethernet SF'), 'Upgrade Type'] = 'Satellite Box: 10G'       
        dfx.loc[(dfx['Node Name'] == i) & (dfx['Port Type'] == '10-Gig Ethernet SF'),  'Upgrade Rank'] = 2  
        
    sat_box_upgrades = set(sat_box1 + sat_box2)      
    return(dfx, sat_box_upgrades)

dfx, sat_box_upgrades = sat_box()
dfx.drop_duplicates(inplace = True)





def output():
    df = dfx[dfx['Upgrade Type'].notnull()]
    df1 = df[[ 'TLA','Region', 'Market ', 'Facility','Node Name','Upgrade Type', 'Upgrade Rank' ]]
    df1.rename(columns = { 'Node Name' :'Parent Device ID'}, inplace = True)
    colo = df1.columns.get_loc('TLA')
    df1.insert(colo + 1,"Co-Lo",'')
    needby = df1.columns.get_loc('Facility')
    df1.insert(needby+1,"Material Need by Date",'')
    df1.insert(needby+2,"Activation Month",'')
    df1.insert(needby+3,"Migration Date",'')
    df1.insert(df1.columns.get_loc('Migration Date') + 1, 'Unique ID', df1['Facility'] +'-'+df1['Upgrade Type'])
    df1.insert(df1.columns.get_loc('Unique ID') + 1, "Program", 'CB Metro Core')
    df1.insert(df1.columns.get_loc('Program') + 1, "Activity Type", '')
    df1.loc[(dfx['Upgrade Type'] == 'FP4 PE ROUTER'),  'Activity Type'] = 'New Build'
    df1.loc[(dfx['Upgrade Type'] != 'FP4 PE ROUTER'),  'Activity Type'] = 'Growth'
    df1.insert(df1.columns.get_loc('Activity Type') + 1, "Scenario", '')
    df1.insert(df1.columns.get_loc('Scenario') + 1, "Quantity", '')
    df1.loc[(dfx['Upgrade Type'] == 'FP4 PE ROUTER'),  "Quantity"] = 2
    df1.loc[(dfx['Upgrade Type'] != 'FP4 PE ROUTER'),  "Quantity"] = 1
    df1.insert(df1.columns.get_loc('Parent Device ID') + 1, "Equipment", '')
    df1.sort_values(by = ['Region'],inplace = True)
    return(df1)

df1 = output()
df1.drop_duplicates( inplace = True)



columns = ['Required'	,'Optional'	,'Required'	,'Required'	,'Required'	,'Required'	,'Required'	,'Optional (for dependencies/ capacity need)' ,	'Required',	'Required',	'Required'	,'Required'	,'Required'	,'Optional'	,'Required'	,'Optional']



writer = pd.ExcelWriter("C:/Users/Mitchell.Ramey/Desktop/AutomationTool/Output/PlanningAutomation_v9.6.xlsx", engine='xlsxwriter')
df1.to_excel(writer, sheet_name='Model Output', index = False)
dfx.to_excel(writer, sheet_name='Data Export', index = False)
metro_final.to_excel(writer, sheet_name='Lag Utl. Forecast', index = False)
access_final.to_excel(writer, sheet_name='Ring Utl. Forecast', index = False)
writer.save()











    
    
    
