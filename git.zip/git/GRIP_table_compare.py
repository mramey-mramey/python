import pandas as pd
import numpy as np

df1 = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/Table Compare/GRIP PBI.csv', dtype= {'Quantity':np.float64})
df2 = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/Table Compare/BC PBI.csv')
df2.rename(columns= {'Amount.1':'Amount_1', 'Description.1':'Description_2'}, inplace = True)
df2 = df2.round({'Quantity':0})

df_merge = df1.merge(df2,indicator = True, how='outer')
df_merge2 = df_merge.set_index('Entry_No')
df_diffs = df_merge2.loc[lambda x : x['_merge']!='both']
df_diffs.rename(columns= {'_merge':'Source'}, inplace = True)
df_diffs.replace('left_only', 'GRIP', inplace = True)
df_diffs.replace('right_only', 'BC', inplace = True)

diff_ids = df_diffs.index.value_counts() > 1
df_diff_only = df_diffs[diff_ids]

df_diff_only = df_diff_only.sort_index(axis = 0)

# Iniialize blank DF for results
df_diff_final = pd.DataFrame()


if not df_diff_only.empty:


    #   Find Differences
    for i in df_diff_only.index.unique():
        df_test2 = df_diff_only.loc[i]
        colList = df_test2.columns.values.tolist()
        df_test2 = df_test2.replace(np.nan, '', regex=True)
        for c in colList:
            if df_test2[c].nunique() == 1 :
                df_test2.drop([c], axis = 1, inplace = True)            
        df_diff_final = df_diff_final.append(df_test2, sort = True)
 