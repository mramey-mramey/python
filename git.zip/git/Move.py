import time
import pyautogui as pag
pag.FAILSAFE = True


while True:
    pag.moveTo(100, 200, duration=1)
    time.sleep(10)
    pag.moveTo(400, 200, duration=1)
    pag.rightClick()
 