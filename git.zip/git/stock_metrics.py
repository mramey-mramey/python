'''
import FundamentalAnalysis as fa


ticker = "LVGO"
api_key = "c0edbb2ed197e8a451a4e212c29cee0c"

key_metrics_annually = fa.key_metrics(ticker, api_key)
print('P/E: ')
print(key_metrics_annually.loc['peRatio', '2019'])
print('RoE: ')
print(key_metrics_annually.loc['roe', '2019'])
print('D/E: ')
print(key_metrics_annually.loc['currentRatio', '2019'])



import pandas as pd
 
tgt_website = r'https://sg.finance.yahoo.com/quote/WDC/key-statistics?p=WDC'
 
def get_key_stats(tgt_website):
 
    # The web page is make up of several html table. By calling read_html function.
    # all the tables are retrieved in dataframe format.
    # Next is to append all the table and transpose it to give a nice one row data.
    df_list = pd.read_html(tgt_website)
    result_df = df_list[0]
 
    for df in df_list[1:]:
        result_df = result_df.append(df)
 
    # The data is in column format.
    # Transpose the result to make all data in single row
    return result_df.set_index(0).T
 
# Save the result to csv
result_df = get_key_stats(tgt_website)

stock_symbol_list = ['LVGO', 'NVCR']

all_result_df = pd.DataFrame()
url_prefix = 'https://sg.finance.yahoo.com/quote/{0}/key-statistics?p={0}'
for sym in stock_symbol_list:
    stock_url = url_prefix.format(sym)
    result_df = get_key_stats(stock_url)
    if len(all_result_df) ==0:
        all_result_df = result_df
    else:
        all_result_df = all_result_df.append(result_df)
        
print(all_result_df['Forward P/E 1'])
print(all_result_df['Return on equity (ttm)'])
print(all_result_df['Current ratio (mrq)'])

'''

import pandas as pd

url_prefix = 'https://sg.finance.yahoo.com/quote/{0}/key-statistics?p={0}'
stock_symbol_list = ['TIGR']

for i in stock_symbol_list:
    print(i)

    stock_url = url_prefix.format(i)
    df_list = pd.read_html(stock_url)
    result = df_list[0]
    result = result.set_index(0).T
    pe = result['Forward P/E 1']
    print('Should be below 20')
    print(pe)
    
    
    roe = df_list[6]
    roe = roe.set_index(0).T
    roe = roe['Return on equity (ttm)']
    print('Above 20')
    print(roe)
    
    
    debtToEquity = df_list[8]
    debtToEquity = debtToEquity.set_index(0).T
    debtToEquity = debtToEquity['Current ratio (mrq)']
    print('Below 1')
    print(debtToEquity)
    

    