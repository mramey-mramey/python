import pandas as pd
import os

#path = 'E:/RetentionForecast/Python'
path = 'C:/Users/Mitchell.Ramey/Desktop/test'



#Import audit_column_names to get list of correct column names
df_audit_columns = pd.read_csv(path + '/segment_leader_summary_audit_column_names.csv')
audit_columns = df_audit_columns.columns

#Initialize list of total number of files and passed/failed list
passed_files = []
failed_files = []

#Loop thru each file ending with xlsx, load the first sheet name in wb & get the list of column names. 
for file in os.listdir(path):
    if file.endswith(".xlsx"): 
        xl = pd.ExcelFile(path + '/' + file)
        sheetname = xl.sheet_names[0] 
        df = pd.read_excel(path + '/' + file, sheet_name = sheetname)
        import_columns = df.columns 
        
        
        #Ensure the columns names & order match
        if len(import_columns)== len(audit_columns) and len(import_columns) == sum([1 for i, j in zip(import_columns, audit_columns) if i == j]): 
            filename = file.replace('.xlsx', '.csv')
            df.to_csv(path + '/'+ filename, index = False)
            passed_files.append(filename)
    
        else : 
            failed_files.append(file)


    
df_passed  = pd.DataFrame(passed_files) 
df_passed.to_csv(path + '/segment_leader_xl_to_csv_passed_files.csv', index = False, header = False)  

df_failed  = pd.DataFrame(failed_files) 
df_failed.to_csv(path + '/segment_leader_xl_to_csv_failed_files.csv', index = False, header = False)  



 

    


 

    

