'''
Given a time series of credit card balances of one consumer, we want to create some attributes. 
Attribute 1: Write a python function to return the average of positive monthly balances over a year. 
Input: a list of non-negative integers representing monthly credit card balances. (list size=12)
Output: Return the average of all positive balances. (output type=int.) 
Zero balances in the input list should be excluded when calculating average. 
If there is no positive balance in the input list, then return 0. 
When the calculated average is a floating number, round it to the nearest integer. 

Example: 
Input is balance = [50, 1, 27, 0, 20, 40, 0, 0, 0, 0, 0, 0]. This consumer spent $50 on Jan, $1 on Feb, $27 on Mar, etc.
Output is 28, because (50+1+27+20+40)/5 = 27.6 and round it to the nearest integer 28. 

'''

def balances(input_list):
    positive_values = []
    for i in input_list:
        if i > 0:
            positive_values.append(i)
            
    result = round(sum(positive_values)/len(positive_values))
    
    return(result)

test = [50, 1, 27, 0, 20, 40, 0, 0, 0, 0, 0, 0]

balances(test)

'''
Attribute 2: Write a python function to return the maximum of monthly balance jumps. 
Balance jump is defined as a positive balance increase amount between two time points. 
Monthly balance jump is defined as the balance jump between two consecutive months.  
If no balance jump exists, return 0.
Example: 
Input is balance = [50, 1, 27, 0, 20, 40, 0, 0, 0, 0, 0, 0].
Output is 26, because there are three monthly balance jumps: 
The balance jump of Feb->Mar is 1->27, which is (27-1) = 26. 
The balance jump of Apr->May is 0->20, which is (20-0) = 20. 
The balance jump of May->Jun is 20->40, which is (40-20) = 20. 
The maximum of [26,20,20] is 26. 

'''


input_test =  [50, 1, 27, 0, 20, 40, 0, 0, 0, 0, 0, 0]

def balance_jumps(input_list):
    
    balance_jump_list = []
    for i in range(0, len(input_list)-1):
        month1 = input_list[i]
        month2 = input_list[i + 1]    
        if month2 > month1:
            result = (month2 - month1)
            balance_jump_list.append(result)
            
            
    return(max(balance_jump_list))


balance_jumps(input_test)
            

'''
Attribute 3: Write a python function to return the maximum of yearly balance jumps. 
Yearly balance jump is defined as the balance jump between any two months. 
If no balance jumps, return 0. 
Example:   
Input is balance = [50, 1, 27, 0, 20, 40, 0, 0, 0, 0, 0, 0].
Output is 40, because the balance jump of Apr->Jun is 0->40, which is (40-0) = 40. 
This balance jump is the maximum balance jump in the input list.
[12,11,10,9,8,7,6,5,4,3,2,1] should return 0. 
[70,40,10,40,70,5,66,1,2,0,0,0]  should return 61.
[70,40,10,40,70,5,60,1,2,0,0,0] should return 60.

'''

input_list = [12,11,10,9,8,7,6,5,4,3,2,1]


def year_bal_jumps(input_list):
    balance_jump_list = []
    for i in range(0, len(input_list)-1):
        current_month = input_list[i]
        remaining_months = input_list[i:]
        if max(remaining_months) > current_month:
            balance_jump_list.append(max(remaining_months) - current_month)
            
    if not balance_jump_list:
        balance_jump_list = 0
    else:
        balance_jump_list = max(balance_jump_list)
            
    return(balance_jump_list)

year_bal_jumps([12,11,10,9,8,7,6,5,4,3,2,1])

            
    
    
    
    



        
            
        