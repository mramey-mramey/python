import pandas as pd
import os
path = os.getcwd()


def get_data():
    
    cards = pd.read_csv("C:/Users/Mitchell.Ramey/Desktop/Lifecycle/Card_Level_crosstab_jun29.csv",converters={'Slot Number':str})
    daughters = cards.loc[lambda x:x['Card Category']=='Daughter Card']
    d_key = daughters['Card Name'].str.lstrip('Daughter Card - ')
    d_key2 = d_key.str.split(' ').str[0]
    daughters['Slot/Subslot'] = d_key2
    daughters['Key2'] = daughters['Node Name'] + d_key2
    daughters['Key'] = daughters['Key2'].str[:-2]
    io = cards.loc[lambda x:x['Card Category']=='IO']
    io['Key'] = io['Node Name'] + io['Slot Number']
    
    
    
    unused_iom = daughters.merge(io, how = 'outer', on = 'Key', indicator = True)
    unused_iom = unused_iom.loc[lambda x:x['_merge'] == 'right_only']
    unused_iom.dropna(axis = 0,subset = ['Card Type _y'], inplace = True)
    unused_iom = unused_iom[unused_iom['Card Type _y'].str.contains("IOM")]
    cards2 = cards.copy()
    cards2['Key'] = cards2['Node Name'] + cards2['Slot Number']
    unused_iom = cards2[cards2['Key'].isin(unused_iom['Key'])]
    
    
    
    daughters = daughters[[ 'Card Type ','Card Name','Slot/Subslot','Key2']]
    daughters = daughters.rename(columns = {'Card Type ':'Daughter Card Type','Card Name': 'Daughter Card Name' })    
    io = cards.loc[lambda x:x['Card Category']=='IO']
    io['Key'] = io['Node Name'] + io['Slot Number']
    io = io[['Card Type ', 'Key']]
    io = io.rename(columns = {'Card Type ':'IO Card Type'})
    
    
    
    ports = pd.read_csv("C:/Users/Mitchell.Ramey/Desktop/Lifecycle/port_details_jun29.csv")
    #ports_10g = ports.loc[lambda x: x['Port Type'] == '10-Gig Ethernet SF' ]
    ports_10g = ports.copy()
    ports_10g['Slot'] = ports_10g['Port'].str.split('/').str[0]
    ports_10g['Key'] = ports_10g['Node Name'] + ports_10g['Slot']
    slot_subslot = ports_10g['Port'].str[:-5]
    ports_10g['Key2'] = ports_10g['Node Name'] +slot_subslot
    
    df1 = ports_10g.merge(io, how = 'inner', on = 'Key')
    df2 = df1.merge(daughters, how = 'inner', on = 'Key2')
    
    
    p = ['P ROUTER','S-PE','HYBRID','NON-CORE', 'RAMP']
    df2 = df2[df2['Role'].isin(p)]
    
    
    portinv = pd.read_csv("C:/Users/Mitchell.Ramey/Desktop/Lifecycle/Port_Level_crosstab_jun29.csv")
    portinv = portinv[['Node Name','Role','Port Type', 'Final Port Count','Slots Available', 'MDA Free Subslot Count','MDA Free Subslot']]
    portinv['Key3'] = portinv['Node Name'] + portinv['Port Type']
    
    
    ports = pd.read_csv("C:/Users/Mitchell.Ramey/Desktop/Lifecycle/port_tracker_jan28.csv")
    ports3 = ports[['Node Name','2018 Port Consumption', '2019 Port Consumption','Hub Class', 'FP4 Router Ship Date', 'Secondary Pair']]
    ports4 = portinv.merge(ports3, how = 'left', on = 'Node Name')
    ports5 = ports4.drop_duplicates()
    
    ports6 = ports5[[ 'Final Port Count', 'Slots Available',
       'MDA Free Subslot Count', 'MDA Free Subslot', 'Key3',
       '2018 Port Consumption', '2019 Port Consumption',
       'Hub Class', 'FP4 Router Ship Date', 'Secondary Pair']]    
    df2['Key3'] = df2['Node Name'] + df2['Port Type']
    df3 = df2.merge(ports6, how = 'left', on =  'Key3')
    
    unused_iom2 = unused_iom.merge(ports5, how = 'left', on =  'Node Name')
    
    unused_iom2 = unused_iom2.loc[lambda x:x['Port Type']=='10-Gig Ethernet SF']
    unused_iom3 = unused_iom2[[ 'Region', 'Market', 'Facility', 'TLA', 'Node Name',
       'Card Category', 'Card Type ', 'Card Name',  'Slot Number',
        'Role', 'Port Type', 'Final Port Count', 'Slots Available',
       'MDA Free Subslot Count', 'MDA Free Subslot', 
       '2018 Port Consumption', '2019 Port Consumption',
       'Hub Class', 'FP4 Router Ship Date']]
    
    return (df3,unused_iom3)

df2,unused_iom = get_data()



###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################



def get_unused_and_grooms():

    imm_keys = df2['Key'].unique().tolist()   
    df_unused_only = pd.DataFrame()
    df_groom = pd.DataFrame()
    
    for i in imm_keys:
        dfx = df2.loc[lambda x: x['Key'] == i] 
        a = dfx['State'] == 'Available'
        avail = a.values.sum()
        used = (~a).values.sum()
        if len(dfx) == avail:
            final_port_ct = dfx['Final Port Count'].iloc[0]
            new_avail = final_port_ct - avail
            dfy = df2.loc[lambda x: x['Key'] == i]
            x = dfy.columns.get_loc('Final Port Count')
            dfy.insert(x+1,"Port Count if Slot is Pulled", new_avail )
            dfy2 = dfy.drop_duplicates(subset = 'Key')
            df_unused_only = df_unused_only.append(dfy2)
        if used <= 2:
            final_port_ct = dfx['Final Port Count'].iloc[0]
            new_avail = final_port_ct - avail        
            if new_avail >= 15:
                dfg = df2.loc[lambda x: x['Key'] == i]
                x = dfg.columns.get_loc('Final Port Count')
                dfg.insert(x+1,"Port Count if Slot is Pulled", new_avail )
                dfg2 = dfg.drop_duplicates(subset = 'Key')
                df_groom = df_groom.append(dfg2)
                
    
    io = ['8-Port 10GE XFP IMM', '2-PAC FP3 IMM', '2 x MDA IOM 4, E',
       '2 x XP MDA IOM 3', '48-Port GIGE SFP IMM', '12-Port 10GE SF IMM',
       'Esat Card', 'XCM7, S', '48-Port GIGE SFP IMM, B',
       '2 x XP MDA IOM 3, C', '48-Port GIGE SFP IMM, C','XCM X16',
       'XCM X20', '2 x XP MDA IOM 3, B', '5-Port 10GE XFP IMM',
       '4-Port 10GE XFP IMM', '7210 IOM', '2 x 10-Gig MDA IOM 2',
       'XCM14, S']
    dfiom= df2[df2['IO Card Type'].isin(io)]
    
    #dfiom = df2.loc[lambda x: x['Port Type'] != 'voice'] 
    #dfiom = dfiom.loc[lambda x: x['Port Type'] != 'gps'] 
    #dfiom = dfiom.loc[lambda x: x['Key2'] != 'VISTCASR1AW-VIST-2405NSANTA-SAR81/1'] 
    #dfiom = dfiom.dropna()
    dfiom['IO Card Type'] = dfiom['IO Card Type'].fillna('')
    dfiom = dfiom[dfiom['IO Card Type'].str.contains("IOM")]
    iom_keys = dfiom['Key2'].unique().tolist()
    
    for i in iom_keys:
        dfx = dfiom.loc[lambda x: x['Key2'] == i] 
        a = dfx['State'] == 'Available'
        avail = a.values.sum()
        used = (~a).values.sum()
        if len(dfx) == avail:
            final_port_ct = dfx['Final Port Count'].iloc[0]
            new_avail = final_port_ct - avail
            dfy = df2.loc[lambda x: x['Key2'] == i]
            x = dfy.columns.get_loc('Final Port Count')
            dfy.insert(x+1,"Port Count if Card is Pulled", new_avail )
            dfy2 = dfy.drop_duplicates(subset = 'Key2')
            df_unused_only = df_unused_only.append(dfy2)
        if used <= 2:
            final_port_ct = dfx['Final Port Count'].iloc[0]
            new_avail = final_port_ct - avail        
            if new_avail >= 15:
                dfg = df2.loc[lambda x: x['Key'] == i]
                x = dfg.columns.get_loc('Final Port Count')
                dfg.insert(x+1,"Port Count if Card is Pulled", new_avail )
                dfg2 = dfg.drop_duplicates(subset = 'Key2')
                df_groom = df_groom.append(dfg2)
                
    
            
    unused_iom_keys = dfiom['Key'].unique().tolist()
    df_unused_iom = pd.DataFrame()
    
    for i in unused_iom_keys:
        dfx = dfiom.loc[lambda x: x['Key'] == i] 
        a = dfx['State'] == 'Available'
        avail = a.values.sum()
        if len(dfx) == avail:
            df_unused_iom = df_unused_iom.append(dfx)
            
            
    #df_groom = df_groom.loc[lambda x: x['Port Type'] == '10-Gig Ethernet SF' ]            
    #df_unused_only = df_unused_only.loc[lambda x: x['Port Type'] == '10-Gig Ethernet SF' ]        
    #df_unused_iom = df_unused_iom.loc[lambda x: x['Port Type'] == '10-Gig Ethernet SF' ]
    unused_iom_key = df_unused_iom['Key'].unique().tolist()  
    df_unused_only['Unused IOM'] = df_unused_only['Key'].isin(unused_iom_key)           
    df_unused_only = df_unused_only.drop_duplicates(subset = 'Key2')
    df_unused_only['Unused Cards per Router'] = df_unused_only.groupby('Node Name')['Node Name'].transform('count')
    
    df_final_unused = df_unused_only[['Region', 'Market', 'Facility', 'TLA', 'Node Type', 'Node Name','Unused Cards per Router', 'IP',
       'Role', 'Port Type', 'Slot/Subslot',  'Description',
       'IO Card Type', 'Daughter Card Type', 'Daughter Card Name',
       'MDA Free Subslot Count', 'MDA Free Subslot', 'Slots Available',
       'Final Port Count', 'Port Count if Slot is Pulled','Port Count if Card is Pulled',
       '2019 Port Consumption', '2018 Port Consumption',
       'Hub Class', 'FP4 Router Ship Date',  'Unused IOM' ,'Secondary Pair']]
    
    df_groom = df_groom[['Region','Market','Facility', 'TLA', 'Node Name', 'Node Type', 'Role','Port','Port Type',  
                         'IO Card Type', 'Daughter Card Type', 'Daughter Card Name',
                         'Final Port Count', 'Slots Available','Hub Class',
            'MDA Free Subslot Count', '2018 Port Consumption', '2019 Port Consumption',
       'FP4 Router Ship Date','IO Card Type','Daughter Card Type',
       'Description',   'Port Count if Card is Pulled', 'Port Count if Slot is Pulled'
       ]]
    
    return(df_final_unused,df_groom, df_unused_iom)
    
    
df_final_unused, df_groom, df_unused_iom = get_unused_and_grooms()

###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################




def get_uplinks_crosslinks():
    df1 = pd.read_csv("C:/Users/Mitchell.Ramey/Desktop/Lifecycle/MetroCore(Nov).csv",converters={'Lag Capacity (Gbps)':str,'Lag Utilization':str})
    df2 = df1.drop_duplicates(subset = ['Router IP', 'Lag', 'Far End IP'])
    df2 = df1.loc[lambda x:x['Far End Router '] != 'Unknown']
    p = ['P','PE']
    
    df3 = df2[df2['Far_End Role'].isin(p)]
    df4 = df3[df3['Role '].isin(p)]
    
    x = df4['Far End Router '] != df4['Router']
    dfx = df4[x]
    
    
    nodes = dfx['Router'].unique().tolist()
    df_cross_uplinks = pd.DataFrame()
    
    for n in nodes:
        dfa = dfx.loc[lambda x: x['Router'] == n]
        crosslinks = []
        uplinks = []  
        up_util = []
        cross_util = []
        up_cap = []
        cross_cap = []

        for i in range(0,len(dfa)):
    
            if dfa['Role '].iloc[i] == 'P' and dfa['Far_End Role'].iloc[i] == 'PE':
                uplinks.append(dfa['Ports within Lag'].iloc[i])
                up_cap.append(dfa['Lag Capacity (Gbps)'].iloc[i])
                up_util.append(dfa['Lag Utilization'].iloc[i])
                
            if dfa['Role '].iloc[i] == 'PE' and dfa['Far_End Role'].iloc[i] == 'P':
                uplinks.append(dfa['Ports within Lag'].iloc[i])
                up_cap.append(dfa['Lag Capacity (Gbps)'].iloc[i])
                up_util.append(dfa['Lag Utilization'].iloc[i])
                
            if dfa['Role '].iloc[i] == 'PE' and dfa['Far_End Role'].iloc[i] == 'PE':
                crosslinks.append(dfa['Ports within Lag'].iloc[i])
                cross_cap.append(dfa['Lag Capacity (Gbps)'].iloc[i])
                cross_util.append(dfa['Lag Utilization'].iloc[i])
                
            if dfa['Role '].iloc[i] == 'P' and dfa['Far_End Role'].iloc[i]== 'P':
                crosslinks.append(dfa['Ports within Lag'].iloc[i])
                cross_cap.append(dfa['Lag Capacity (Gbps)'].iloc[i])
                cross_util.append(dfa['Lag Utilization'].iloc[i])
                
                
        if not crosslinks:
            crosslinks.append('Not Found')
        if not uplinks:
            uplinks.append('Not Found')
            
        if not up_cap:
            up_cap.append('Not Found')
        if not cross_cap:
            cross_cap.append('Not Found')
            
        if not up_util:
            up_util.append('Not Found')
        if not cross_util:
            cross_util.append('Not Found')
            
        if len(crosslinks) > 1:
            crosslinks = [', '.join(crosslinks[:])]                
        if len(uplinks) > 1:
            uplinks = [', '.join(uplinks[:])] 

        if len(up_cap) > 1:
            up_cap = [', '.join(up_cap[:])]                
        if len(cross_cap) > 1:
            cross_cap = [', '.join(cross_cap[:])]       
            
        if len(up_util) > 1:
            up_util = [', '.join(up_util[:])]                
        if len(cross_util) > 1:
            cross_util = [', '.join(cross_util[:])]   
                
                
        my_dict = {'Router':n, 'Crosslinks': crosslinks, 'Crosslink Capacity': cross_cap, 'Crosslink Utilization': cross_util,
                   'Uplinks':uplinks, 'Uplink Capacity': up_cap, 'Uplink Utilization': up_util,    }   
    
        my_df = pd.DataFrame(my_dict)  
        df_cross_uplinks = df_cross_uplinks.append(my_df)    
     
    df_cross_uplinks = df_cross_uplinks.rename(columns = {'Router':'Node Name'})    
    return(df_cross_uplinks)


uplinks_crosslinks = get_uplinks_crosslinks()


def poi(): 
    #Merge port data with static POI data to determine when facilities are receiving FP4 routers
    #dfx_final = dfx.copy()
    dffp4 = pd.read_csv('C:/Users/Mitchell.Ramey/Desktop/Lifecycle/FP4 Sites_v4.csv')
    #P Routers & Hybrids
    dffp4['tla_key'] = dffp4['TLA'] + dffp4['Role']
    dfx2 = df_final_unused.copy()
    dfx2['tla_key'] = dfx2['TLA'] + dfx2['Role']    
    dfz = dffp4[['tla_key','FP4 Router Type', 'FP4 Need By Date']].drop_duplicates()
    df1 = dfx2.merge(dfz,  on = 'tla_key', how = 'left')      

    #PE Routers   

    
    

    return(df1)
    
df_final_unused = poi()



###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################


unused_iom2 = unused_iom.merge(uplinks_crosslinks, how = 'left', on = 'Node Name')
df_final2 = df_final_unused.merge(uplinks_crosslinks, how = 'left', on = 'Node Name')


writer = pd.ExcelWriter("C:/Users/Mitchell.Ramey/Desktop/FP3_Card_Reallocation_jun29_v1.xlsx", engine='xlsxwriter')
unused_iom2.to_excel(writer, sheet_name='Unused IOM', index = False)
df_final2.to_excel(writer, sheet_name='Unused Cards', index = False)
df_groom.to_excel(writer, sheet_name='Potential Grooming Cards', index = False)
df2.to_excel(writer, sheet_name='Raw Data', index = False)
writer.save()



